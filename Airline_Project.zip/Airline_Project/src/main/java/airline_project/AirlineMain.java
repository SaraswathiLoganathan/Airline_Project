package airline_project;

import java.sql.SQLException;
import java.util.Scanner;


public class AirlineMain {

	public static void main(String[] args) throws SQLException {
		
		Scanner sc=new Scanner (System.in);
		System.out.println("****Welcome****");
		System.out.println("Travel Joy Airline Reservation");
		System.out.println("are you admin or user?");
		
		while (true) {
		System.out.println("1.admin");
		System.out.println("2.user");
		int n=sc.nextInt();
		
		switch(n) {
		case 1:
			
			System.out.println("enter admin username");
			String un=sc.next();
			System.out.println("enter admin password");
			String up=sc.next();

			if(un.equals("admin")&&up.equals("admin@123")) {
				System.out.println("Login successfull");
				while (true) {
				
				System.out.println("choose the action you want to do");
				System.out.println("1.diplay single record");
				System.out.println("2.display seat reserved");
				int choice=sc.nextInt();
				
				switch(choice) {
				case 1:
					System.out.println("Your choosen display single records process");
					AirlineOperation.displayRervation();
					break;
				case 2:
					System.out.println("Your choosen seat reserved process");
					AirlineOperation.Seatreservation();
					break;
					
				default:
					System.out.println("invalid input");
				}//switch
				System.out.println("do you want to continue y/n");
				char ch=sc.next().charAt(0);
				if(ch=='n'|| ch=='N')
					break;		
				}	//while(true)
			}	
			else {
				System.out.println("incorrect username or password");
				
			}
			System.out.println("you are terminated");
			break;
			
			
			
			//user process
		case 2:
			
			System.out.println("you are in user portal");
			System.out.println("enter user name");
			String un1=sc.next();
			System.out.println("enter password");
			String up1=sc.next();
			if(un1.equals("saras")&&up1.equals("saras@123")) {
				System.out.println("Login successfull");
				while(true) {
				System.out.println("choose the action you want to do");
				System.out.println("1.Seat Reservation");
				System.out.println("2.Seat Cancellation");
				
				int choice2=sc.nextInt();
				switch(choice2) {
				case 1:
					System.out.println("displaying your record");
					AirlineOperation.seatReservation();
					break;
				
				case 2:
					System.out.println("Seat cancelling process");
					AirlineOperation.seatCancellation();
					break;
				
					
			default:
					System.out.println("invalid input");
			}
			
			System.out.println("do you want to continue y/n");
			char ch=sc.next().charAt(0);
			if(ch=='n'|| ch=='N')
				break;
			}
			
		}
		else {
			System.out.println("incorrect username or password");
		}
		System.out.println("you are terminated");
	
		
		
		break;
		
		default:
		System.out.println("invalid input");
		
		
	}//switch
	System.out.println("do you to return to home page y/n");
	char ch=sc.next().charAt(0);
	if(ch=='n'|| ch=='N')
		break;
	

	
	

	}
	System.out.println("you are terminated");
	


}
}

		
				
				

		
		
		
	



				
			